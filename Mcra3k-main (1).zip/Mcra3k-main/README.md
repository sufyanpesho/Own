# Mcra3k
Tools Fb Crack  (frind list  public id   fallowers an file )  pass choice 10
# Mcra3k
crack fb New 
# Mcra3k crack fb 
###  crack   publick id  & fallower post frind list   !!
# thise script free
[![Author](https://img.shields.io/badge/Author-Mohammad_sultani-blue.svg?style=for-the-badge)](https://github.com/mohammadjan1122)
[![Python](https://img.shields.io/badge/Code-Python-green.svg?style=flat-square)](#)


### [+] Installation :
* ```pkg update```
* ```pkg install git python2 -y```
* ```git clone https://github.com/Mohammadjan1122/Mcra3k```
* ```cd Mcra3k```
* ```python2 Mcra3k.py```

### Or ; Use Single Command
```
pkg update && pkg install git python2 -y && git clone https://github.com/Mohammadjan1122/Mcra3k && cd Mcra3k && python2 Mcra3k.py
```
### Find Me On :
[![Github](https://img.shields.io/badge/Github-Mohammadjan1122-green?style=for-the-badge&logo=github)](https://github.com/Mohammadjan1122)
[![Instagram](https://img.shields.io/badge/IG-%40mohammad_sultani-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/mohammad_sultani1122)
[![Telegram](https://img.shields.io/badge/telegram-blue?style=for-the-badge&logo=telegram)](https://t.me/sultani1122)


#mohammad_sultani
